<?php

// заносим все необходимые данные, которые будут использоваться на странице.
return [
  'about'=>[
      'name' => 'Timur Kilchukov',
      'post' => 'Developer',
      'email' => 'Kilchukovtimur2000@yandex.ru',
      'phone' => '89280817072',
      'site' => 'google.com'
  ],
    'education' => [
        [
            'faculty' => 'MSc in Information systems and technologies',
            'university' => 'Moscow State University',
            'yearStart' => '2022',
            'yearEnd' => '2024'
        ],
        [
            'faculty' => 'BSc in Information systems and technologies',
            'univercity' => 'Moscow Aviation Institute',
            'yearStart' => '2018',
            'yearEnd' => '2022'
        ]
    ],
    'languages' => [
        'Russian (Professional)', 'English(B1)', 'Circassian(Native)'
    ],
    'interests' => [
        'Basketball', 'Travel'
    ],
    'career' => 'Started to develop in September 2018. Now wanna work combining with study.',
    'experiences' => [
        'work1' => [
            'name' => 'Practice at the University',
            'time' => '2018 - 2019',
            'post' => 'Trainee',
            'details' => 'Every summer I ave got practice in university related to programming'
        ],
        'work2' => [
            'name' => 'Internship',
            'time' => '2020',
            'post' => 'Intern',
            'details' => '3 month internship in the field of web development(Javascript,NodeJS,React)'
        ],
    ],
    'projects' => [
        'JS' => [
                'name' => 'Js - constructor ',
                'work' => 'Here is simple constructor on JS. Used base syntax,objects, etc.',
                'href' => 'https://github.com/TimurKilch/js-constuctor'
            ],
        'Python' => [
            'name' => 'Python',
            'work' => 'A game that uses the pygame library. There is object recognition and drawing of the visual component of the game',
            'href' => 'https://github.com/TimurKilch/pygame'
        ],
        'NodeJS' => [
            'name' => 'NodeJs',
            'work' => 'Creating a server on nodejs. Ability to perform database operations based on phpmyadmin',
            'href' => 'https://github.com/TimurKilch/NodeJs'
        ]
    ],
    'projIntro' => [
        'intro' => 'Here you can see my projects.',
        'href' => 'https://github.com/TimurKilch',
    ],
    'skills' => [
        'JS' => [
            'name' => 'Javascript',
            'level' => '50%'
        ],
        'Python' => [
            'name' => 'Python',
            'level' => '30%'
        ],
        'NodeJS' => [
            'name' => 'NodeJS',
            'level' => '45%'
        ],
        'React' => [
            'name' => 'React Native',
            'level' => '50%'
        ],
        'PHP' => [
            'name' => 'PHP',
            'level' => '30%'
        ]
    ]
];